"use client";

import { useEffect, useMemo, useState } from "react";

export default function BeautyAffiliateFunnel() {
  const [scrollY, setScrollY] = useState(0);
  const isScrolled = scrollY > 40;

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY || 0);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const featuredProducts = useMemo(
    () => [
      {
        name: "Pure Argan Oil (Cold-Pressed)",
        category: "Berber Skincare",
        benefit: "Deep hydration, glow enhancement, and a rich natural glow.",
        price: "$60-$150",
        link: "#",
        image:
          "https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=1200&q=80",
        badge: "#1 Best Seller",
      },
      {
        name: "Argan Hair Elixir",
        category: "Haircare",
        benefit: "Smooth frizz, restore shine, and strengthen hair naturally.",
        price: "$80-$200",
        link: "#",
        image:
          "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1200&q=80",
        badge: "Luxury Pick",
      },
      {
        name: "Moroccan Black Soap",
        category: "Spa Ritual",
        benefit: "Traditional hammam cleansing for soft, glowing skin.",
        price: "$40-$120",
        link: "#",
        image:
          "https://images.unsplash.com/photo-1556228578-8c89e6adf883?auto=format&fit=crop&w=1200&q=80",
        badge: "Tourist Favorite",
      },
    ],
    []
  );

  const blogPosts = useMemo(
    () => [
      {
        title: "Authentic vs Fake Argan Oil (MUST READ BEFORE BUYING)",
        excerpt: "This is your highest converting article. Educates, builds trust, and sells.",
        href: "#",
      },
      {
        title: "Top Moroccan Beauty Secrets Used by Berber Women",
        excerpt: "Story-driven content that attracts organic traffic and builds authority.",
        href: "#",
      },
      {
        title: "Best Argan Oil Brands from Morocco (2026 Guide)",
        excerpt: "Comparison-style article that converts visitors into buyers.",
        href: "#",
      },
    ],
    []
  );

  return (
    <div className="min-h-screen bg-[#f7f3ed] text-[#2d2a26]">
      {/* Mobile CTA Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-between bg-[#7a5c1e] px-4 py-3 text-white sm:hidden">
        <span className="text-sm">Get Real Argan Oil</span>
        <a href="#products" className="rounded-lg bg-white px-3 py-1 text-sm font-semibold text-black">
          Shop
        </a>
      </div>

      {/* Header */}
      <header
        className="fixed left-0 right-0 top-0 z-30 transition-all duration-500 ease-out"
        style={{
          backgroundColor: isScrolled ? "rgba(20, 18, 16, 0.8)" : "transparent",
          backdropFilter: isScrolled ? "blur(14px) saturate(140%)" : "none",
          boxShadow: isScrolled ? "0 10px 30px rgba(0,0,0,0.08)" : "none",
        }}
      >
        <div
          className={`mx-auto flex max-w-7xl items-center justify-between px-4 text-white transition-all duration-500 ease-out ${
            isScrolled ? "py-3" : "py-5"
          }`}
        >
          <div className="flex items-center gap-3 transition-all duration-500 ease-out">
            <div
              className={`relative flex items-center justify-center rounded-full bg-gradient-to-br from-[#f4d06f] via-[#c6922b] to-[#7a5c1e] shadow-lg ring-2 ring-white/20 transition-all duration-500 ease-out ${
                isScrolled ? "h-9 w-9 rotate-[8deg]" : "h-10 w-10 rotate-0"
              }`}
            >
              <div className="absolute h-4 w-4 rounded-full border border-white/40" />
              <div className="h-1.5 w-5 rounded-full bg-white/80" />
            </div>
            <div className="transition-all duration-500 ease-out">
              <p
                className={`uppercase tracking-[0.35em] text-white/70 transition-all duration-500 ease-out ${
                  isScrolled ? "text-[9px]" : "text-[10px]"
                }`}
              >
                Organic Gardens
              </p>
              <h1
                className={`font-bold tracking-wide transition-all duration-500 ease-out ${
                  isScrolled ? "text-lg" : "text-xl"
                }`}
              >
                Argania Luxe
              </h1>
            </div>
          </div>
          <nav className="hidden gap-6 text-sm font-medium sm:flex">
            <a href="#products" className="transition duration-300 hover:text-[#f4d06f] hover:-translate-y-0.5">
              Products
            </a>
            <a href="#blog" className="transition duration-300 hover:text-[#f4d06f] hover:-translate-y-0.5">
              Guides
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative flex h-[90vh] items-center justify-center overflow-hidden px-4 text-center text-white">
        <div
          className="absolute inset-0 scale-110"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1800&q=80')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            transform: `translateY(${scrollY * 0.35}px) scale(1.12)`,
            willChange: "transform",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/45 via-black/40 to-black/55" />

        <div className="relative z-10 mt-16 max-w-2xl">
          <h2 className="text-4xl font-bold leading-tight sm:text-6xl text-balance">Discover Authentic Moroccan Beauty</h2>
          <p className="mt-4 text-lg text-gray-200">
            Real argan oil, Berber traditions, and luxury natural skincare.
          </p>

          <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
            <a href="#products" className="rounded-xl bg-[#7a5c1e] px-6 py-3 font-semibold text-white transition hover:bg-[#8f6d25]">
              Shop Real Products
            </a>
            <a href="#blog" className="rounded-xl border border-white px-6 py-3 transition hover:bg-white/10">
              Learn First
            </a>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="bg-white py-12 text-center">
        <h3 className="text-2xl font-semibold">Why People Trust This Site</h3>
        <p className="mx-auto mt-4 max-w-xl text-[#5c5248]">
          We focus only on authentic Moroccan products. No fake blends, no misleading claims.
        </p>
      </section>

      {/* Products Section */}
      <section id="products" className="mx-auto max-w-7xl px-4 py-14">
        <h3 className="text-3xl font-bold">Top Recommended Argan Products</h3>

        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {featuredProducts.map((p) => (
            <div key={p.name} className="overflow-hidden rounded-2xl bg-white shadow transition hover:shadow-lg">
              <img src={p.image} alt={p.name} className="h-48 w-full object-cover" />

              <div className="p-5">
                <span className="rounded bg-[#f3ede4] px-2 py-1 text-xs">{p.badge}</span>
                <h4 className="mt-2 text-lg font-semibold">{p.name}</h4>
                <p className="mt-2 text-sm text-[#5c5248]">{p.benefit}</p>
                <p className="mt-2 font-bold">{p.price}</p>

                <a href={p.link} className="mt-4 block rounded-xl bg-black py-2 text-center font-semibold text-white transition hover:bg-[#2d2a26]">
                  View Product
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Blog Section */}
      <section id="blog" className="bg-[#fffaf5] px-4 py-14">
        <div className="mx-auto max-w-6xl">
          <h3 className="text-3xl font-bold">Guides That Convert</h3>

          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {blogPosts.map((post) => (
              <div key={post.title} className="rounded-xl bg-white p-5 shadow transition hover:shadow-lg">
                <h4 className="font-semibold">{post.title}</h4>
                <p className="mt-2 text-sm text-[#5c5248]">{post.excerpt}</p>
                <a href={post.href} className="mt-4 inline-block text-sm underline transition hover:text-[#7a5c1e]">
                  Read Article
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Email Capture Section */}
      <section className="px-4 py-16 text-center">
        <h3 className="text-3xl font-bold">Free Guide</h3>
        <p className="mt-3">How to Spot Real Argan Oil in Morocco</p>

        <div className="mt-6 flex flex-col justify-center gap-2 sm:flex-row">
          <input className="rounded-xl border px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#7a5c1e]" placeholder="Enter email" />
          <button className="rounded-xl bg-[#7a5c1e] px-4 py-2 text-white transition hover:bg-[#8f6d25]">Get Guide</button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#2d2a26] py-6 text-center text-white">
        <p>&copy; Argania Luxe</p>
      </footer>
    </div>
  );
}
